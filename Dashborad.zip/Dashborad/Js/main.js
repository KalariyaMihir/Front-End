$(document).ready(function () {
     $("#frm").bValidator();
});

function login() {
     let em = document.getElementById("email").value;
     let pas = document.getElementById("pwd").value;
  
     if (em === 'pirateskull@gmail.com' && pas === 'admin1234') {
        alert("You are logged in successfully");
        return true; // Allow the form to submit and redirect to "dashboard.html"
     } else {
        alert("Your email and password are incorrect, please try again");
        return false; // Prevent the form from submitting
     }
  };

  
//   logout function of dashboard
function lgbtn(){
   alert('You are logged out successfully');
   window.location='index.html';
}

// function for alphabetic order
function validateFirstName() {
   let fnameInput = document.getElementById('fname');
   let fnameValue = fnameInput.value;

   // Use a regular expression to check if the input contains only alphabetic characters
   if (/[^a-zA-Z]/.test(fnameValue)) {
       // If it contains non-alphabetic characters, clear the input and show an alert
       alert('Please enter only alphabetic characters in the First Name field.');
       fnameInput.value = '';
   }
}

function validateLastName() {
   let fnameInput = document.getElementById('lname');
   let fnameValue = fnameInput.value;

   // Use a regular expression to check if the input contains only alphabetic characters
   if (/[^a-zA-Z]/.test(fnameValue)) {
       // If it contains non-alphabetic characters, clear the input and show an alert
       alert('Please enter only alphabetic characters in the Last Name field.');
       fnameInput.value = '';
   }
}